﻿using System.Xml;
string GHXPath = "Layout.ghx";
XmlDocument doc = new XmlDocument();
doc.Load(GHXPath);
XmlNodeList listNodes = doc.DocumentElement.SelectNodes("/Archive/chunks/chunk/chunks/chunk");
XmlNode ObjectNode = null;
foreach (XmlNode node in listNodes)
{
    foreach (XmlAttribute j in node.Attributes)
    {
        if (j.Value == "DefinitionObjects")
        {
            ObjectNode = node;
            break;
        }
        else
        {
        }
    }
}
int count = 1;
foreach (XmlNode node in ObjectNode.SelectNodes("chunks/chunk"))
{
    string result = "";
    foreach (XmlNode node1 in node.SelectNodes("items/item"))
    {
        foreach (XmlAttribute j in node1.Attributes)
        {
            if (j.Value == "Name" && node1.InnerText != "Group")
            {
                result += "Name" + count + "=" + node1.InnerText;
                count++;
            }
        }
    }
    result += ",";
    count--;
    foreach (XmlNode node1 in node.SelectNodes("chunks/chunk/chunks/chunk/items/item"))
    {
        foreach (XmlAttribute m in node1.Attributes)
        {
            if (m.Value == "Bounds")
            {
                foreach (XmlNode n in node1.ChildNodes)
                {
                    string key = "";
                    if (n.Name == "X")
                    {
                        key = "P";
                    }
                    else if (n.Name == "Y")
                    {
                        key = "Q";
                    }
                    else
                    {
                        key = n.Name;
                    }
                    result += key + count + "=" + n.InnerText + ",";
                }
            }
        }
    }
    count++;
    result = result.Substring(0, result.Length - 1);
    if (result != "")
    {
        Console.WriteLine(result);
    }
}