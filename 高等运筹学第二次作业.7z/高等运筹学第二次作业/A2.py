import random
import time


def GenerateCoordinate(N):
    # (int) x or y >=0
    # (int) x or y < 100
    a = [[random.randint(0, 100) for j in range(2)] for i in range(N)]
    return a

def Coordinate2Distance(Coordinate):
    L = len(Coordinate)
    # fill with 0
    Distance =  [[0 for i in range(L)] for j in range(L)]
    for FromIndex, FromItem in enumerate(Coordinate):
        for ToIndex, ToItem in enumerate(Coordinate):
            if FromIndex < ToIndex:
                FromX = FromItem[0]
                FromY = FromItem[1]
                ToX = ToItem[0]
                ToY = ToItem[1]
                Distance[FromIndex][ToIndex] = ( (ToX - FromX) ** 2 + (ToY - FromY) ** 2) ** 0.5
            elif FromIndex > ToIndex:
                # flip the matrix => for example: a[2][1] = a[1][2]
                Distance[FromIndex][ToIndex] = Distance[ToIndex][FromIndex]
    return Distance

# function: generate initial solution
def initial_solution(length):
    solution = [0] *length
    i = 0
    while i <length:
        solution[i] = i 
        i = i + 1 
    return solution

# function: copy solution
def copy_solution(sol):
    newsol = [0] * len(sol)
    i=0
    while i <len(sol):
        newsol[i] = sol[i]
        i = i + 1
    return newsol

# function: evaluate the fitness of a given solution
def fitness(solution, C):
    ans = 0
    i = 0
    while i< len(solution):
        if i + 1 < len(solution):
            ans	= ans + C[solution[i]][solution[i +1]]	
        else:
            ans	= ans + C[solution[i]][solution[0]]	
        i = i + 1
    return ans

# function: generate neighborhood solution
def neighborhood(solution, location):
    newsol = copy_solution(solution)
    tempt =newsol[location]
    if location + 1 < len(solution):
        newsol[location] = newsol[location + 1]
        newsol[location + 1] =tempt 
    else:
        newsol[location] = newsol[0]	
        newsol[0] = tempt
    return newsol

if __name__ == "__main__":
    start_time = time.time()
    Coordinate = GenerateCoordinate(100) # 10, 20, 30, 40, ����, 80, 90, 100
    Distance = Coordinate2Distance(Coordinate)

    # define initial solution
    size = len(Distance)
    seq = initial_solution(size)
    obj = fitness(seq, Distance)
    print("initial solution :", seq)
    print("initial fitness :", obj)

    # local search procedure
    iter = 1
    termination_flag = False
    # while iter <= 50:
    while termination_flag != True:
        print("-------------------------------")
        print("iter : ", iter)

        # search for best neighborhood solution
        localseq = copy_solution(seq)
        localobj = obj
        loc = 0
        while loc < size:	
            newseq = neighborhood(seq, loc)
            newobj= fitness(newseq, Distance)
            if newobj < localobj:
                localseq = newseq
                localobj = newobj
                print("updated solution : ", localseq)
                print("updated fitness : ", localobj)
            loc = loc + 1	

        # update best solution
        if localobj < obj:
            seq = copy_solution(localseq)
            obj = localobj
        else:
            print("no better neighborhood solution is found")
            termination_flag = True
        iter = iter + 1

    end_time = time.time()
    print("need time: %s"%(end_time - start_time))

